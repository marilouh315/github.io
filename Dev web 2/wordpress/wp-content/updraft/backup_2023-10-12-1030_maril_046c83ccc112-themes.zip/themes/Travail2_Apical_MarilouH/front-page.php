<!DOCTYPE html>
<html lang="en"> 
<head>
    <title>Apical | Travail 2</title>
    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Reproduction du site web de Christiane, Apical, sur Wordpress comme TP 2 en Dev. Web 2">
    <meta name="author" content="Marilou Héon">    
    
	<!-- Theme CSS -->
	<link rel="stylesheet" href="wp-content/themes/Travail2_Apical_MarilouH/assets/css/cssBase.css">

    <!-- Google Font - "Raleway" -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@300;400;500&display=swap" rel="stylesheet">
    
    <!-- JavaScript
    <script defer src="wp-content/themes/Travail2_Apical_MarilouH/assets/js/jsBase.js"></script> -->


</head> 

<body>
    <header class="entete_principal"> 
        <div class="premier_menu">
            <div class="menu_container">
                <div class="gauche1">
                    <div class="gauche2">
                        <a href="#" class="titre_Apical">
                            <img src="https://apical.xyz/medias/fr/LogoApical-blanc.svg" width="350px" alt="Logo Apical">
                        </a>  
                    </div> 
                </div>
                
                <div class="droite">
                    <div class="menu_icones">
                        <a href="" class="home icones " >
                            <span class="tooltip" data-tooltip="Menu Principal">
                            <img class="image_icones" src="https://apical.xyz/medias/commun/Accueil-MenuSecondaire.svg" alt="Logo Apical">
                            </span>
                        </a>
                        <a href="" class="favoris icones ">
                            <span class="tooltip" data-tooltip="Favoris">
                            <img class="image_icones" src="https://apical.xyz/medias/commun/Favoris-MenuSecondaire.svg" alt="Logo Apical">
                            </span>
                        </a>
                        <a href="" class="rechercher icones ">
                            <span class="tooltip"  data-tooltip="Recherche">
                            <img class="image_icones" src="https://apical.xyz/medias/commun/Rechercher-MenuSecondaire.svg" alt="Logo Apical">
                            </span>
                        </a>
                        <a href="" class="connection icones ">
                            <span class="tooltip" data-tooltip="Authentification">
                            <img class="image_icones" src="https://apical.xyz/medias/commun/LoginFait-MenuSecondaire.svg" alt="Logo Apical">
                            </span>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <nav class="menu_navigation">
            <div class="menu_navBar">
                <ul class="liste_link_nav">
                    <li class="item_nav">
                        <div class="dropdown_nav_link">
                            <a href="#" class="nav_link">
                                Formations
                            </a>
                        </div>
                        <div class="dropdown dropdown_formation" id="dropdown">
                            <h6>Dernières formations consultées</h6>
                            <a class="dropdown_item" href="#">Réinitialiser la liste</a>
                        </div>
                    </li>
                    <li class="item_nav">
                        <div class="dropdown_nav_link">
                            <a href="#" class="nav_link">
                                Questionnaires/ 
                                Evaluations
                            </a>
                        </div>
                        <div class="dropdown dropdown_questions" id="dropdown">
                            <a class="dropdown_item" href="#">Questionnaires</a>
                            <div class="dropdown_divider"></div>
                            <a class="dropdown_item" href="#">Résultats évaluations</a>
                        </div>
                    </li>
                    <li class="item_nav">
                        <a href="#" class="nav_link">
                            Travaux
                        </a>
                    </li>
                    <li class="item_nav">
                        <a href="#" class="nav_link">
                            Blogue
                        </a>
                    </li>
                    <li class="item_nav">
                        <div class="dropdown_nav_link">
                            <a href="#" class="nav_link">
                                Outils
                            </a>
                        </div>
                        <div class="dropdown dropdown_outils" id="dropdown">
                            <a class="dropdown_item" href="#">Hachage bcrypt</a>
                            <div class="dropdown_divider"></div>
                            <a class="dropdown_item" href="#">Générateur aléatoire</a>
                            <div class="dropdown_divider"></div>
                            <a class="dropdown_item" href="#">Icônes Font Awesome</a>
                        </div>
                    </li>
                    <li class="item_nav">
                        <a href="#" class="nav_link">
                            Mon Profil
                        </a>
                    </li>
                    <li class="item_nav">
                        <div class="dropdown_nav_link">
                            <a href="#" class="nav_link">
                                Aide
                            </a>
                        </div>
                        <div class="dropdown dropdown_help" id="dropdown">
                            <a class="dropdown_item" href="#">Contact</a>
                            <div class="dropdown_divider"></div>
                            <a class="dropdown_item" href="#">À propos</a>
                        </div>
                    </li>

                </ul>
            </div>
        </nav>
    </header>

    <div class="container_principal">
        <div class="container_formations">
            <div class="titre_container">
                <hr class="hr_divider" width="250px" height="10px" backgroung-color="black">
                <h1>
                    <?php $year = date("Y"); echo "Formations PUB020 : Wordpress, " . $year;?> 
                </h1>
                <hr class="hr_divider" width="250px" height="10px" backgroung-color="black">
            </div>

            <div class="contenu">
                <div class="container_bouton">
                    <button class="bouton_developper" id="expand_all toggleButton">
                        Tout développer
                    </button>
                </div>

                <div class="contenu_formation">
                    <div class="drag_chapitre collapsible">
                        <div class="chapitre1">
                            <div class="chapitre2 collapsible-header">
                                <a class="lien_chapitre collapsible">
                                    <span>1. Choisir les outils pour développer un site WordPress</span>
                                </a>
                            </div>
                        </div>
                        <div class="collapse_chapitre">
                            <div class="collapse_fiche_chapitre">
                                <ul class="collapse_liste">
                                    <li class="collapse_item collapsible-content">
                                        <a href="#" class="collapse_link">
                                            1.1 Choisir un IDE pour coder en PHP
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="drag_chapitre collapsible">
                        <div class="chapitre1">
                            <div class="chapitre2 collapsible-header">
                                <a class="lien_chapitre">
                                    <span>2. Travailler avec PHPStorm</span>
                                </a>
                            </div>
                        </div>
                        <div class="collapse_chapitre">
                            <div class="collapse_fiche_chapitre">
                                <ul class="collapse_liste">
                                    <li class="collapse_item collapsible-content">
                                        <a href="#" class="collapse_link">
                                            2.1 Création d'un compte étudiant chez JetBrains
                                        </a>
                                    </li>
                                    <li class="collapse_item collapsible-content">
                                        <a href="#" class="collapse_link">
                                            2.2 Installation de PhpStorm
                                        </a>
                                    </li>
                                    <li class="collapse_item collapsible-content">
                                        <a href="#" class="collapse_link">
                                            2.3 Renouveler la license de PhpStorm                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="drag_chapitre collapsible">
                        <div class="chapitre1">
                            <div class="chapitre2 collapsible-header">
                                <a class="lien_chapitre">
                                    <span>3. Travailler avec Devilbox</span>
                                </a>
                            </div>
                        </div>
                        <div class="collapse_chapitre">
                            <div class="collapse_fiche_chapitre">
                                <ul class="collapse_liste">
                                    <li class="collapse_item collapsible-content">
                                        <a href="#" class="collapse_link">
                                            3.1 Installation de Devilbox
                                        </a>
                                    </li>
                                    <li class="collapse_item collapsible-content">
                                        <a href="#" class="collapse_link">
                                            3.2 Accéder au terminal d'un conteneur Docker
                                        </a>
                                    </li>
                                    <li class="collapse_item collapsible-content">
                                        <a href="#" class="collapse_link">
                                            3.3 Accéder à phpMyAdmin sous Devilbox
                                        </a>
                                    </li>
                                    <li class="collapse_item collapsible-content">
                                        <a href="#" class="collapse_link">
                                            3.4 Modification d'un fichier .env de DevilBox
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="drag_chapitre collapsible">
                        <div class="chapitre1">
                            <div class="chapitre2 collapsible-header">
                                <a class="lien_chapitre">
                                    <span>4. Les gestionnaires de contenus</span>
                                </a>
                            </div>
                        </div>
                        <div class="collapse_chapitre">
                            <div class="collapse_fiche_chapitre">
                                <ul class="collapse_liste">
                                    <li class="collapse_item collapsible-content">
                                        <a href="#" class="collapse_link">
                                            4.1 Qu'est-ce qu'un CMS ?
                                        </a>
                                    </li>
                                    <li class="collapse_item collapsible-content">
                                        <a href="#" class="collapse_link">
                                            4.2 Combien coûte un CMS ? 
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="drag_chapitre collapsible">
                        <div class="chapitre1">
                            <div class="chapitre2 collapsible-header">
                                <a class="lien_chapitre">
                                    <span>5. Installation de WordPress</span>
                                </a>
                            </div>
                        </div>
                        <div class="collapse_chapitre">
                            <div class="collapse_fiche_chapitre">
                                <ul class="collapse_liste">
                                    <li class="collapse_item collapsible-content">
                                        <a href="#" class="collapse_link">
                                            5.1 Installation de Wordpress
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="drag_chapitre collapsible">
                        <div class="chapitre1">
                            <div class="chapitre2 collapsible-header">
                                <a class="lien_chapitre">
                                    <span>6. Aménager notre environnement pour travailler plus efficacement</span>
                                </a>
                            </div>
                        </div>
                        <div class="collapse_chapitre">
                            <div class="collapse_fiche_chapitre">
                                <ul class="collapse_liste">
                                    <li class="collapse_item collapsible-content">
                                        <a href="#" class="collapse_link">
                                            6.1 Ouvrir un projet Wordpress dans PhpStorm
                                        </a>
                                    </li>
                                    <li class="collapse_item collapsible-content">
                                        <a href="#" class="collapse_link">
                                            6.2 Travailer avec deux onglets : le site de Wordpress et le tableau de bord
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="drag_chapitre collapsible">
                        <div class="chapitre1">
                            <div class="chapitre2 collapsible-header">
                                <a class="lien_chapitre">
                                    <span>7. Écrire un programme WordPress de qualité</span>
                                </a>
                            </div>
                        </div>
                        <div class="collapse_chapitre">
                            <div class="collapse_fiche_chapitre">
                                <ul class="collapse_liste">
                                    <li class="collapse_item collapsible-content">
                                        <a href="#" class="collapse_link">
                                            7.1 Les qualités d'un bon programme Wordpress
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                        
                </div>

            </div>

        </div>
    </div>

    <footer>
        <div class="pied_de_page">
            <div class="container_copyright">
                <div class="container_copyright"> 
                    <div class="copyright text_footer">
                        <?php $year = date("Y"); echo $year . " Tous droits réservés."?> 
                    </div>
                </div>
            </div>
            <div class="container_auteur">
                <div class="container_auteur2">
                    <div class="auteur text_footer">
                        Conception et développement initial de la plateforme : Christiane Lagacé <br>
                        <h4>
                            Holà, toujours présente comme étudiante au Cégep de Victoriaville, maintenant en Techniques de l'informatique,
                            j'ai bien hâte de voir si j'ai la patience et la determination d'aller essayer la dépression de l'université. 
                            Souhaitez-moi la meilleure des chances!
                        </h4>
                    </div>
                </div>
            </div>
            <div class="container_bouton">
                <div class="container_bouton2">
                    <button class="bouton_suivre text_footer">
                        Écrivez-moi!
                    </button>
                </div>
            </div>
        </div>
    </footer>

    <!-- JavaScript -->
    <script src="wp-content/themes/Travail2_Apical_MarilouH/assets/js/jsBase.js"></script>

</body>
</html> 

