    <footer>
        <p>&copy; <?php echo date("Y"); ?> Mon Site Web</p>
    </footer>
    <?php wp_footer(); ?>
  </body>
</html>